SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

REPLACE="
"

ui_print "
╔═══╗
║╔═╗║
║║─╚╬══╦╗╔╦╦═╗╔══╗
║║╔═╣╔╗║╚╝╠╣╔╗╣╔╗║
║╚╩═║╔╗║║║║║║║║╚╝║
╚═══╩╝╚╩╩╩╩╩╝╚╩═╗║
──────────────╔═╝║
──────────────╚══╝ "
ui_print "__________________________"
ui_print ""
ui_print "  ESPORT GAMING NEXT GEN  "
ui_print "__________________________"
ui_print " Esport Gaming "
ui_print " Dev : HenVx "
ui_print " Versi : 9.9.9 FINAL "
ui_print ""
ui_print ""
ui_print ""
ui_print ""
ui_print " NEXT GEN ESPORT MODULE "
ui_print " Date : 31-7-2023 Build "
ui_print " Developer Indonesia Tweak's"