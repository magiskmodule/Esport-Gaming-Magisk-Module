#!/bin/sh

sleep 20

chmod 000 /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu1/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu2/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu3/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu5/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu6/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu7/cpufreq/cpuinfo_max_freq

chmod 000 /sys/devices/system/cpu/cpu0/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu1/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu2/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu3/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu4/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu5/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu6/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu7/cpu_capacity

chmod 000 /sys/devices/system/cpu/cpu0/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu1/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu2/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu3/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu4/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu5/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu6/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu7/topology/physical_package_id

echo 0 > /sys/devices/system/cpu/cpu0/core_ctl/enable


function wait_sixty_second() {
sleep 60
}

function get_busybox_dir() {
BUSYBOX=$(find /data/adb/ -type f -name busybox | head -n 1)
}

function set_log_dir() {
LOG=/data/media/0/Android/fstrim.log
}

function get_exec_date() {
DATE=${date}
}

function empty_debug_log() {
echo "" > "$LOG"
}

function run_fstrim_debug() {
$BUSYBOX fstrim -v $1 >> "$LOG"
}

wait_sixty_second

get_busybox_dir

set_log_dir

empty_debug_log

run_fstrim_debug /system
run_fstrim_debug /vendor
run_fstrim_debug /metadata
run_fstrim_debug /odm
run_fstrim_debug /system_ext
run_fstrim_debug /data
run_fstrim_debug /cache


echo "0" > /proc/sys/kernel/panic
echo "0" > /proc/sys/kernel/panic_on_oops
echo "0" > /proc/sys/kernel/panic_on_rcu_stall
echo "0" > /proc/sys/kernel/panic_on_warn
echo "0" > /sys/module/kernel/parameters/panic
echo "0" > /sys/module/kernel/parameters/panic_on_warn
echo "0" > /sys/module/kernel/parameters/panic_on_oops
echo "0" > /sys/vm/panic_on_oom

echo "3" > /proc/sys/vm/drop_caches

echo "512" > /sys/devices/virtual/bdi/179:0/read_ahead_kb (Class 3 And Lower)

for queue in /sys/block/mmcblk*/queue; do
echo "0" > $queue/add_random
echo "0" > $queue/iostats
echo "128" > $queue/read_ahead_kb
echo "64" > $queue/nr_requests
done

for governor in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
    echo performance > $governor
done