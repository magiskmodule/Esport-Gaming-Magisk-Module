SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false

REPLACE="
"

ui_print "
╔═══╗
║╔═╗║
║║─╚╬══╦╗╔╦╦═╗╔══╗
║║╔═╣╔╗║╚╝╠╣╔╗╣╔╗║
║╚╩═║╔╗║║║║║║║║╚╝║
╚═══╩╝╚╩╩╩╩╩╝╚╩═╗║
──────────────╔═╝║
──────────────╚══╝ "
ui_print "__________________________"
ui_print ""
ui_print "  ESPORT GAMING NEXT GEN  "
ui_print "__________________________"
ui_print " Esport Gaming "
ui_print " Dev : HenBz10 "
ui_print " Versi : 3.0  "
ui_print ""
ui_print ""
ui_print ""
ui_print " Gaming Tweak's Loading .... "
ui_print ""
ui_print ""
ui_print ""
ui_print " NEXT GEN ESPORT MODULE "
ui_print " Date : 31-7-2023 Build "
ui_print " Developer Indonesia Tweak's"
